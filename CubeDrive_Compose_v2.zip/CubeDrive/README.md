# Cube Drive (Android, Jetpack Compose)
UI demo of the launcher for Minecraft Bedrock Edition. Navigation works; launch/download buttons are disabled stubs.

Stack: Kotlin, Jetpack Compose, Material 3, Navigation Compose.

Build: push to GitHub -> Actions -> "Build APK" -> download artifact `CubeDrive-debug-apk`.
If `.github/workflows/android.yml` is missing, create it from `android.yml` in the repo root.
