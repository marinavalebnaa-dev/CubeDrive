package com.cubedrive.launcher.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun VersionsScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Версії", "Обери потрібну версію Minecraft", Icons.AutoMirrored.Filled.List)
        SearchField("Пошук версії...")
        ChipRow(listOf("Всі", "Release", "Beta", "Preview"))
        EmptyState(
            title = "Версій поки немає",
            text = "Список з\u2019явиться пізніше. Завантаження вимкнено."
        ) {
            StubButton("Оновити список", Modifier.fillMaxWidth())
        }
    }
}
