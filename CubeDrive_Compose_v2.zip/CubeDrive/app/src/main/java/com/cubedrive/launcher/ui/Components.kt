package com.cubedrive.launcher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CubeLogo(logoSize: Dp = 40.dp) {
    Canvas(Modifier.size(logoSize)) {
        val w = this.size.width
        val h = this.size.height
        val top = Path().apply {
            moveTo(w * 0.5f, 0f); lineTo(w, h * 0.25f); lineTo(w * 0.5f, h * 0.5f); lineTo(0f, h * 0.25f); close()
        }
        val left = Path().apply {
            moveTo(0f, h * 0.25f); lineTo(w * 0.5f, h * 0.5f); lineTo(w * 0.5f, h); lineTo(0f, h * 0.75f); close()
        }
        val right = Path().apply {
            moveTo(w, h * 0.25f); lineTo(w * 0.5f, h * 0.5f); lineTo(w * 0.5f, h); lineTo(w, h * 0.75f); close()
        }
        drawPath(top, Color(0xFF5AB0FF))
        drawPath(left, Color(0xFF1E7BFF))
        drawPath(right, Color(0xFF1558C0))
    }
}

/** Disabled stub button: looks like a button, does nothing. */
@Composable
fun StubButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    height: Dp = 44.dp
) {
    Button(
        onClick = {},
        enabled = false,
        modifier = modifier.height(height),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            disabledContainerColor = Accent.copy(alpha = 0.4f),
            disabledContentColor = Color.White.copy(alpha = 0.7f)
        )
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = Accent)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = TextDim, fontSize = 14.sp)
        }
    }
}

@Composable
fun SearchField(hint: String, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        modifier = modifier.fillMaxWidth(),
        placeholder = { Text(hint, color = TextDim) },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextDim) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = Border,
            focusedBorderColor = Accent,
            unfocusedContainerColor = Surface1,
            focusedContainerColor = Surface1
        )
    )
}

@Composable
fun ChipRow(items: List<String>, modifier: Modifier = Modifier) {
    var selected by remember { mutableIntStateOf(0) }
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEachIndexed { i, label ->
            FilterChip(
                selected = selected == i,
                onClick = { selected = i },
                label = { Text(label) },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = Surface1,
                    labelColor = TextDim,
                    selectedContainerColor = Accent,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

data class CatalogItem(
    val name: String,
    val description: String,
    val rating: String,
    val colors: List<Color>
)

@Composable
fun CatalogCard(item: CatalogItem, action: String) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .clip(shape)
            .background(Surface1)
            .border(1.dp, Border, shape)
            .padding(8.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.linearGradient(item.colors))
        )
        Spacer(Modifier.height(8.dp))
        Text(item.name, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(item.description, color = TextDim, fontSize = 12.sp, maxLines = 2, minLines = 2)
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
            Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFC107), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(item.rating, fontSize = 13.sp)
        }
        StubButton(action, Modifier.fillMaxWidth(), height = 38.dp)
    }
}

@Composable
fun CatalogScreen(
    items: List<CatalogItem>,
    action: String,
    header: @Composable () -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { header() }
        }
        items(items) { CatalogCard(it, action) }
    }
}

@Composable
fun EmptyState(title: String, text: String, modifier: Modifier = Modifier, content: @Composable () -> Unit = {}) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Surface1)
            .border(1.dp, Border, shape)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(text, color = TextDim, fontSize = 14.sp)
        content()
    }
}
