package com.cubedrive.launcher.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ProfileScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Профіль", "Керуй своїми акаунтами", Icons.Default.Person)

        Text("Офлайн-режим", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Accent)
        var nick by remember { mutableStateOf("") }
        OutlinedTextField(
            value = nick,
            onValueChange = { nick = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Нікнейм") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = Border,
                focusedBorderColor = Accent,
                unfocusedContainerColor = Surface1,
                focusedContainerColor = Surface1
            )
        )
        StubButton("Грати (офлайн)", Modifier.fillMaxWidth(), Icons.Default.PlayArrow)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HorizontalDivider(Modifier.weight(1f), color = Border)
            Text("Або", color = TextDim)
            HorizontalDivider(Modifier.weight(1f), color = Border)
        }

        StubButton("Увійти через Microsoft", Modifier.fillMaxWidth(), height = 52.dp)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Мої акаунти", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            StubButton("Додати", icon = Icons.Default.Add, height = 38.dp)
        }
        EmptyState("Акаунтів поки немає", "Додай акаунт, щоб він з\u2019явився тут.")
    }
}
