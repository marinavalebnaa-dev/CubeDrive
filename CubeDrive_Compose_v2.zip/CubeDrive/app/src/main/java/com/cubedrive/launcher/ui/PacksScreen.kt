package com.cubedrive.launcher.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val demoPacks = listOf(
    CatalogItem("Класичні HD", "Чіткі текстури в HD.", "4.7", listOf(Color(0xFF2E7D4F), Color(0xFF8BC34A))),
    CatalogItem("Мінімалізм", "Прості чисті текстури.", "4.6", listOf(Color(0xFF1B3A6B), Color(0xFF90CAF9))),
    CatalogItem("Реалістичні шейдери", "Світло, тіні та вода.", "4.8", listOf(Color(0xFF6A1B9A), Color(0xFFFF8A65))),
    CatalogItem("Легкий", "Для слабких телефонів.", "4.4", listOf(Color(0xFF455A64), Color(0xFF81C784))),
    CatalogItem("Об\u2019ємні блоки", "3D-вигляд блоків.", "4.5", listOf(Color(0xFF33691E), Color(0xFF64B5F6))),
    CatalogItem("Яскравий світ", "Насичені кольори.", "4.7", listOf(Color(0xFFAD1457), Color(0xFFFFB74D)))
)

@Composable
fun PacksScreen() {
    CatalogScreen(items = demoPacks, action = "Застосувати") {
        ScreenHeader("Ресурс-паки", "Текстури та шейдери в форматі .mcpack", Icons.Default.Create)
        SearchField("Пошук ресурс-паків...")
        ChipRow(listOf("Усі", "Текстури", "Шейдери"))
    }
}
