package com.cubedrive.launcher.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Demo data only (design preview). Real Bedrock content will be added later.
private val demoAddons = listOf(
    CatalogItem("Нові мобі", "Додає нових істот у світ.", "4.8", listOf(Color(0xFF2E7D4F), Color(0xFF5AB0FF))),
    CatalogItem("Біоми+", "Додаткові біоми та структури.", "4.6", listOf(Color(0xFF1B5E3A), Color(0xFF8BC34A))),
    CatalogItem("Зброя та інструменти", "Нові предмети для виживання.", "4.7", listOf(Color(0xFF1B3A6B), Color(0xFF42A5F5))),
    CatalogItem("Меблі", "Декор для будинку.", "4.5", listOf(Color(0xFF6D4C41), Color(0xFFFFB74D))),
    CatalogItem("Техніка", "Машини та механізми.", "4.8", listOf(Color(0xFFE08A3C), Color(0xFF2E7D4F))),
    CatalogItem("Магія", "Заклинання та зілля.", "4.7", listOf(Color(0xFF6A1B9A), Color(0xFFFF8A65)))
)

private val demoMods = listOf(
    CatalogItem("Міні-карта", "Зручна навігація світом.", "4.6", listOf(Color(0xFF33691E), Color(0xFFCDDC39))),
    CatalogItem("Інвентар+", "Швидке сортування предметів.", "4.5", listOf(Color(0xFF455A64), Color(0xFF81C784))),
    CatalogItem("Показ координат", "Координати на екрані.", "4.7", listOf(Color(0xFF1B3A6B), Color(0xFF90CAF9))),
    CatalogItem("Графіка+", "Покращення вигляду гри.", "4.4", listOf(Color(0xFFAD1457), Color(0xFFFFB74D)))
)

@Composable
fun AddonsScreen() {
    var kind by remember { mutableIntStateOf(0) }
    CatalogScreen(
        items = if (kind == 0) demoAddons else demoMods,
        action = "Встановити"
    ) {
        ScreenHeader("Аддони", "Файли .mcaddon та .mcpack в один клік", Icons.Default.Build)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Аддони", "Модифікації").forEachIndexed { i, name ->
                FilterChip(
                    selected = kind == i,
                    onClick = { kind = i },
                    label = { Text(name) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Surface1,
                        labelColor = TextDim,
                        selectedContainerColor = Accent,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
        SearchField(if (kind == 0) "Пошук аддонів..." else "Пошук модифікацій...")
        ChipRow(listOf("Всі", "Популярні", "Пригоди", "Декор", "Магія"))
    }
}
