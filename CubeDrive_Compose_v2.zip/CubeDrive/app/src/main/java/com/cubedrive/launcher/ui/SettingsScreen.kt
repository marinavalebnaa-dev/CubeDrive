package com.cubedrive.launcher.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ScreenHeader("Налаштування", "Налаштуй лаунчер під себе", Icons.Default.Settings)
        Text("Загальні налаштування", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        SettingSwitch("Темна тема", true)
        SettingSwitch("Автоматично перевіряти оновлення", true)
        SettingSwitch("Показувати новини", true)
        SettingSwitch("Сповіщення", false)
        Spacer(Modifier.height(8.dp))
        StubButton("Зберегти", Modifier.fillMaxWidth())
    }
}

@Composable
private fun SettingSwitch(title: String, initial: Boolean) {
    var checked by remember { mutableStateOf(initial) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = { checked = it },
            colors = SwitchDefaults.colors(checkedTrackColor = Accent)
        )
    }
}
