package com.cubedrive.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0A1220)
val Surface1 = Color(0xFF111D35)
val Accent = Color(0xFF1E7BFF)
val Border = Color(0xFF24457A)
val TextDim = Color(0xFF9FB3D1)
val Green = Color(0xFF2ECC71)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    background = Bg,
    onBackground = Color.White,
    surface = Surface1,
    onSurface = Color.White,
    surfaceVariant = Surface1,
    onSurfaceVariant = TextDim,
    outline = Border,
    secondaryContainer = Color(0xFF1B3F7A),
    onSecondaryContainer = Color.White
)

@Composable
fun CubeDriveTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
