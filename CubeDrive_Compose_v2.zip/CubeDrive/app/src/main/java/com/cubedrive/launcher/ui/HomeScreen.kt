package com.cubedrive.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1B3A6B), Color(0xFF2E7D4F), Color(0xFFE08A3C))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CubeLogo(56.dp)
                Spacer(Modifier.height(8.dp))
                Text("CUBE DRIVE", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Text("ТВІЙ ВЛАСНИЙ СВІТ", fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
            }
        }

        StubButton("ГРАТИ", Modifier.fillMaxWidth(), Icons.Default.PlayArrow, height = 60.dp)

        // Version selector (view only, not clickable)
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Surface1)
                .border(1.dp, Border, shape)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Остання версія", fontWeight = FontWeight.Bold)
                Text("Не вибрано", color = TextDim)
            }
            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextDim)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickCard("Аддони", "Скоро", Icons.Default.Build, Modifier.weight(1f)) { onOpen("addons") }
            QuickCard("Ресурс-паки", "Скоро", Icons.Default.Create, Modifier.weight(1f)) { onOpen("packs") }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Surface1)
                .border(1.dp, Border, shape)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Info, contentDescription = null, tint = Accent)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Новини", fontWeight = FontWeight.Bold)
                Text("Тут з\u2019являться новини лаунчера.", color = TextDim, fontSize = 13.sp)
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(Green))
            Spacer(Modifier.width(8.dp))
            Text("Демо-інтерфейс: запуск і завантаження вимкнені", color = TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .background(Surface1)
            .border(1.dp, Border, shape)
            .clickable { onClick() }
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Accent)
        Text(title, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(subtitle, color = TextDim, fontSize = 12.sp)
    }
}
